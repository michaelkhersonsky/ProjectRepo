<?php
/**
 * Aliases for iframepage
 *
 * @file
 * @ingroup Extensions
 */

$specialPageAliases = array();

/** English
 * @author Ike Hecht
 */
$specialPageAliases[ 'en' ] = array(
	'IframePage' => array( 'IframePage', 'Iframe Page' ),
);
